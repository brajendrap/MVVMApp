# Auto App - Jetpack Compose
Finding the car

* UI
    * Compose
    * Material design

* Tech stuff
    * Kotlin
    * Coroutines
    
* Modern Architecture
    * Single activity architecture
    * MVVM for presentation layer
    * Modularized architecture
   
    